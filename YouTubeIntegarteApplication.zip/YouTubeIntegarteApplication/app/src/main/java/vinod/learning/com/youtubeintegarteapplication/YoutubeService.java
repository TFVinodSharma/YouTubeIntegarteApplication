package vinod.learning.com.youtubeintegarteapplication;

public class YoutubeService {
    public YoutubeService() {
    }

    private  static final String  api="AIzaSyCNQiw4EURqKlEiVVmk5nsbJzpnoGq4Z7k";

    public String getApi() {
        return api;
    }
}
